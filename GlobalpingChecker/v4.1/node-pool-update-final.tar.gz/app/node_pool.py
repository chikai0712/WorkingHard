"""
GlobalpingChecker V4.1 - Node Pool Manager
管理和驗證節點池
"""
import asyncio
import httpx
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from sqlalchemy.orm import Session
from sqlalchemy import Column, Integer, String, DateTime, Boolean

from .database import Base, get_db_session
from .node_validator import NodeValidator
from .config import get_settings

settings = get_settings()


class NodePool(Base):
    """節點池數據表"""
    __tablename__ = "node_pool"
    
    id = Column(Integer, primary_key=True, index=True)
    node_id = Column(String, unique=True, index=True)  # Globalping 節點 ID
    node_ip = Column(String)
    country = Column(String, index=True)
    country_name = Column(String)
    city = Column(String)
    isp = Column(String)
    asn = Column(String)
    is_active = Column(Boolean, default=True)
    last_verified = Column(DateTime)
    created_at = Column(DateTime, default=datetime.now)


class NodePoolManager:
    """節點池管理器"""
    
    def __init__(self):
        self.api_url = settings.globalping_api_url
        self.token = settings.globalping_token
        self.headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        self.validator = NodeValidator()
        self.target_countries = settings.target_country_list
    
    async def initialize_node_pool(self):
        """初始化節點池"""
        print("🔍 初始化節點池...")
        
        for country in self.target_countries:
            print(f"   獲取 {country} 節點...")
            nodes = await self.fetch_country_nodes(country)
            
            if nodes:
                await self.save_nodes_to_db(nodes, country)
                print(f"   ✅ {country}: 已保存 {len(nodes)} 個節點")
            else:
                print(f"   ⚠️  {country}: 未找到可用節點")
    
    async def fetch_country_nodes(self, country: str) -> List[Dict]:
        """從 Globalping 獲取指定國家的所有節點
        通過創建測量請求來發現可用節點
        """
        try:
            async with httpx.AsyncClient() as client:
                # 使用測量請求來發現節點（減少 limit 以節省 API 額度）
                payload = {
                    "type": "ping",
                    "target": "google.com",
                    "limit": 10,  # 減少到 10 個節點以節省 API 額度
                    "locations": [{"country": country}]
                }
                
                response = await client.post(
                    f"{self.api_url}/measurements",
                    json=payload,
                    headers=self.headers,
                    timeout=30.0
                )
                
                if response.status_code != 202:
                    if response.status_code == 429:
                        print(f"      ⚠️  API 速率限制，請等待幾分鐘後再試")
                    else:
                        print(f"      ❌ API 錯誤: {response.status_code}")
                    return []
                
                data = response.json()
                measure_id = data.get("id")
                
                if not measure_id:
                    print(f"      ❌ 未獲得測量 ID")
                    return []
                
                # 等待結果
                await asyncio.sleep(5)
                
                # 獲取結果
                result_response = await client.get(
                    f"{self.api_url}/measurements/{measure_id}",
                    headers=self.headers,
                    timeout=30.0
                )
                
                if result_response.status_code != 200:
                    print(f"      ❌ 獲取結果失敗: {result_response.status_code}")
                    return []
                
                result_data = result_response.json()
                country_nodes = []
                
                # 從結果中提取節點信息
                for result in result_data.get("results", []):
                    probe = result.get("probe", {})
                    
                    if probe.get("country") != country:
                        continue
                    
                    # 獲取節點 IP
                    node_ip = ""
                    resolvers = probe.get("resolvers", [])
                    if resolvers:
                        node_ip = resolvers[0] if resolvers[0] != "private" else "private"
                    
                    # 只對公網 IP 進行驗證，private IP 直接信任 Globalping 的國家標記
                    if node_ip and node_ip != "private" and not node_ip.startswith("10.") and not node_ip.startswith("192.168.") and not node_ip.startswith("172."):
                        ip_validation = await self.validator.validate_ip(node_ip)
                        if ip_validation["country_code"] != country:
                            print(f"      ⚠️  過濾: {node_ip} 實際屬於 {ip_validation['country_code']}")
                            continue
                    
                    node = {
                        "node_id": f"{country}-{probe.get('city', 'unknown')}-{len(country_nodes)}",  # 生成唯一 ID
                        "node_ip": node_ip,
                        "country": country,
                        "country_name": probe.get("country"),
                        "city": probe.get("city", "Unknown"),
                        "isp": probe.get("network", "Unknown"),
                        "asn": str(probe.get("asn", "")),
                    }
                    country_nodes.append(node)
                
                return country_nodes
                
        except Exception as e:
            print(f"      ❌ 獲取節點失敗: {e}")
            return []
    
    async def save_nodes_to_db(self, nodes: List[Dict], country: str):
        """保存節點到資料庫"""
        from .database import SessionLocal
        db = SessionLocal()
        try:
            for node in nodes:
                # 檢查節點是否已存在
                existing = db.query(NodePool).filter(
                    NodePool.node_id == node["node_id"]
                ).first()
                
                if existing:
                    # 更新現有節點
                    existing.last_verified = datetime.now()
                    existing.is_active = True
                else:
                    # 新增節點
                    db_node = NodePool(
                        node_id=node["node_id"],
                        node_ip=node["node_ip"],
                        country=node["country"],
                        country_name=node["country_name"],
                        city=node["city"],
                        isp=node["isp"],
                        asn=node["asn"],
                        last_verified=datetime.now()
                    )
                    db.add(db_node)
            
            db.commit()
        except Exception as e:
            db.rollback()
            print(f"      ❌ 保存節點失敗: {e}")
        finally:
            db.close()
    
    def get_country_nodes(self, country: str, limit: int = 3) -> List[str]:
        """從資料庫獲取指定國家的節點 ID"""
        from .database import SessionLocal
        db = SessionLocal()
        try:
            nodes = db.query(NodePool).filter(
                NodePool.country == country,
                NodePool.is_active == True
            ).limit(limit).all()
            
            return [node.node_id for node in nodes]
        finally:
            db.close()
    
    async def refresh_node_pool(self):
        """刷新節點池（每天執行一次）"""
        print("🔄 刷新節點池...")
        await self.initialize_node_pool()
        print("✅ 節點池刷新完成")
    
    def get_node_pool_stats(self) -> Dict:
        """獲取節點池統計"""
        from .database import SessionLocal
        db = SessionLocal()
        try:
            stats = {}
            for country in self.target_countries:
                count = db.query(NodePool).filter(
                    NodePool.country == country,
                    NodePool.is_active == True
                ).count()
                stats[country] = count
            
            return stats
        finally:
            db.close()
